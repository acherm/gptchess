import sys
import re

def parse_log(log_filename):
    """
    Reads log.txt and returns a dictionary:
       move_reasoning["1. e4"] = "Reasoning text..."
       move_reasoning["2. d4"] = "Reasoning text..."
    etc.

    This assumes each 'DeepSeek response' block in log.txt looks like:
        DeepSeek response: <played_move>1. e4</played_move>, ...
        Reasoning:  some text here...
    """
    move_reasoning = {}
    with open(log_filename, "r", encoding="utf-8") as f:
        lines = f.readlines()

    current_move = None
    current_reasoning = []

    # We'll accumulate reasoning lines until we see the next 'DeepSeek response'
    for line in lines:
        line = line.strip()

        # Detect "DeepSeek response: <played_move>...some move...</played_move>"
        if "DeepSeek response:" in line and "<played_move>" in line:
            # If we already had a move and reasoning accumulated, store it:
            if current_move and current_reasoning:
                # Join all lines of reasoning
                move_reasoning[current_move] = " ".join(current_reasoning).strip()
            # Reset for new block
            current_move = None
            current_reasoning = []

            # Extract the move from e.g. <played_move>1. e4</played_move>
            match = re.search(r"<played_move>(.*?)</played_move>", line)
            if match:
                # E.g. "1. e4" or "e4"
                current_move = match.group(1).strip()

        # Detect "Reasoning: " lines -> accumulate them
        elif line.startswith("Reasoning:"):
            # everything after 'Reasoning:' is reasoning text
            reasoning_text = line[len("Reasoning:"):].strip()
            current_reasoning.append(reasoning_text)
        else:
            # If we're in the middle of accumulating reasoning, grab extra lines
            if current_move and current_reasoning != []:
                # Continue adding lines to the reasoning block
                current_reasoning.append(line)

    # After loop ends, store the last block if present
    if current_move and current_reasoning:
        move_reasoning[current_move] = " ".join(current_reasoning).strip()

    return move_reasoning

def annotate_pgn(pgn_filename, move_reasoning, output_filename):
    """
    Reads game.pgn line by line, looks for moves like '1. e4', '2. d4', etc.
    If found in move_reasoning dict, inserts a PGN comment { ... } after that move.

    Writes out annotated PGN to output_filename.
    """
    with open(pgn_filename, "r", encoding="utf-8") as f_in:
        pgn_lines = f_in.readlines()

    annotated_lines = []

    # A very naive approach:
    # We'll split each line by spaces, check if token is e.g. '1.', 'e4', etc.
    # Then reassemble.
    # We'll store an internal "previous token" so if we see '1.' and next token 'e4',
    # we can match "1. e4".

    for line in pgn_lines:
        # If it's a header or blank, just copy it
        if line.strip().startswith("[") or line.strip() == "":
            annotated_lines.append(line)
            continue

        tokens = line.split()
        new_tokens = []

        prev_token = None
        for token in tokens:
            # If previous token is something like '1.' and this token is 'e4',
            # that forms '1. e4'. Let's see if it's in move_reasoning.
            combined = None
            if prev_token and re.match(r"^\d+\.$", prev_token):
                combined = prev_token + " " + token  # e.g. "1. e4"

            if combined and combined in move_reasoning:
                # Insert the move + {reasoning}
                reasoning_text = move_reasoning[combined]
                annotated = f"{prev_token} {token} {{{reasoning_text}}}"
                # Replace the last token in new_tokens with the annotated version
                new_tokens[-1] = annotated
                prev_token = None  # reset
            else:
                # otherwise, just push token
                new_tokens.append(token)
                prev_token = token

        # reassemble line
        annotated_line = " ".join(new_tokens)
        annotated_lines.append(annotated_line + "\n")

    # Write the result
    with open(output_filename, "w", encoding="utf-8") as f_out:
        f_out.writelines(annotated_lines)

def main():
    if len(sys.argv) != 4:
        print("Usage: python merge_pgn_logs.py <game.pgn> <log.txt> <annotated_game.pgn>")
        sys.exit(1)

    pgn_file = sys.argv[1]
    log_file = sys.argv[2]
    out_file = sys.argv[3]

    # 1) parse the log
    move_dict = parse_log(log_file)

    # 2) annotate the PGN
    annotate_pgn(pgn_file, move_dict, out_file)

    print(f"Annotated PGN saved to {out_file}")

if __name__ == "__main__":
    main()
